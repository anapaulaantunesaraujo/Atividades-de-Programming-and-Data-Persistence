﻿namespace Cadastro_de_Clientes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btngravarpais = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtnomepais = new System.Windows.Forms.TextBox();
            this.txtcodigospedpais = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btngravarpais
            // 
            this.btngravarpais.Location = new System.Drawing.Point(279, 49);
            this.btngravarpais.Name = "btngravarpais";
            this.btngravarpais.Size = new System.Drawing.Size(75, 23);
            this.btngravarpais.TabIndex = 0;
            this.btngravarpais.Text = "Gravar";
            this.btngravarpais.UseVisualStyleBackColor = true;
            this.btngravarpais.Click += new System.EventHandler(this.btngravarpais_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(251, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Código SPED";
            // 
            // txtnomepais
            // 
            this.txtnomepais.Location = new System.Drawing.Point(12, 23);
            this.txtnomepais.Name = "txtnomepais";
            this.txtnomepais.Size = new System.Drawing.Size(236, 20);
            this.txtnomepais.TabIndex = 3;
            // 
            // txtcodigospedpais
            // 
            this.txtcodigospedpais.Location = new System.Drawing.Point(254, 23);
            this.txtcodigospedpais.Name = "txtcodigospedpais";
            this.txtcodigospedpais.Size = new System.Drawing.Size(100, 20);
            this.txtcodigospedpais.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 86);
            this.Controls.Add(this.txtcodigospedpais);
            this.Controls.Add(this.txtnomepais);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btngravarpais);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btngravarpais;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtnomepais;
        private System.Windows.Forms.TextBox txtcodigospedpais;
    }
}

