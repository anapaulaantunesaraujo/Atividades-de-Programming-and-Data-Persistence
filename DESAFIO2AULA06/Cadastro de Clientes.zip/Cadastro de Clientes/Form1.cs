﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Cadastro_de_Clientes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btngravarpais_Click(object sender, EventArgs e)
        {
            BancoDados bd = new BancoDados();
            CA_PAIS p = new CA_PAIS
            {
                NOME = txtnomepais.Text,
                CODIGOSPED = Convert.ToInt32(txtcodigospedpais.Text)
        };
            bd.CA_PAIS.Add(p);
            bd.SaveChanges();

            
        }
    }
}
