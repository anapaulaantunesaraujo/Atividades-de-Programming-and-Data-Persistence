namespace Cadastro_de_Clientes
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class BancoDados : DbContext
    {
        public BancoDados()
            : base("name=BancoDados")
        {
        }

        public virtual DbSet<CA_CLIENTE> CA_CLIENTE { get; set; }
        public virtual DbSet<CA_ESTADO> CA_ESTADO { get; set; }
        public virtual DbSet<CA_MUNICIPIO> CA_MUNICIPIO { get; set; }
        public virtual DbSet<CA_PAIS> CA_PAIS { get; set; }


        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CA_CLIENTE>()
                .Property(e => e.NOME)
                .IsUnicode(false);

            modelBuilder.Entity<CA_CLIENTE>()
                .Property(e => e.CPF)
                .IsUnicode(false);

            modelBuilder.Entity<CA_CLIENTE>()
                .Property(e => e.RG)
                .IsUnicode(false);

            modelBuilder.Entity<CA_CLIENTE>()
                .Property(e => e.LOGRADOURO)
                .IsUnicode(false);

            modelBuilder.Entity<CA_ESTADO>()
                .Property(e => e.NOME)
                .IsUnicode(false);

            modelBuilder.Entity<CA_ESTADO>()
                .Property(e => e.CODIGOIBGE)
                .IsUnicode(false);

            modelBuilder.Entity<CA_MUNICIPIO>()
                .Property(e => e.NOME)
                .IsUnicode(false);

            modelBuilder.Entity<CA_MUNICIPIO>()
                .Property(e => e.CODIGOIBGE)
                .IsUnicode(false);

            modelBuilder.Entity<CA_PAIS>()
                .Property(e => e.NOME)
                .IsUnicode(false);
        }
    }
}
