namespace Cadastro_de_Clientes
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class CA_MUNICIPIO
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }

        [StringLength(50)]
        public string NOME { get; set; }

        [StringLength(14)]
        public string CODIGOIBGE { get; set; }

        public int? IDESTADO { get; set; }

        public int? IDPAIS { get; set; }
    }
}
