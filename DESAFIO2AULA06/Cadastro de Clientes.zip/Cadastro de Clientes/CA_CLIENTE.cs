namespace Cadastro_de_Clientes
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class CA_CLIENTE
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }

        [StringLength(50)]
        public string NOME { get; set; }

        [StringLength(14)]
        public string CPF { get; set; }

        [StringLength(20)]
        public string RG { get; set; }

        public int? IDMUNICIPIO { get; set; }

        public int? IDESTADO { get; set; }

        [StringLength(100)]
        public string LOGRADOURO { get; set; }

        public int? NUMERO { get; set; }
    }
}
